#ifndef _PARAM_H_
#define _PARAM_H_

/*
 * sys\param.h doesn't exist on NT, so we'll make one.
 */

#define NBPG 4096

#endif /* _PARAM_H_ */

