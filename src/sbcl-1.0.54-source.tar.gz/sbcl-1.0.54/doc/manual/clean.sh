#!/bin/sh

. ../../find-gnumake.sh
find_gnumake
$GNUMAKE clean
