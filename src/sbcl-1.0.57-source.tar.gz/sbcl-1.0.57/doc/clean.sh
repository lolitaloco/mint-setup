#!/bin/sh

(cd manual; sh clean.sh)
